// Chart primitives + small helpers. Babel JSX.
// Exposes to window for cross-file usage.

const SKILL_KEYS = ['speaking', 'listening', 'reading', 'writing', 'grammar'];
const SKILL_LABELS_PT = {
  speaking: 'Fala',
  listening: 'Audição',
  reading: 'Leitura',
  writing: 'Escrita',
  grammar: 'Gramática',
};

// ── Pips (filled circles 1–5) ──
function Pips({ value, max = 5, size = 'md', color }) {
  const items = [];
  for (let i = 1; i <= max; i++) {
    items.push(
      <span
        key={i}
        className={"pip" + (i <= value ? " is-on" : "")}
        style={color && i <= value ? { background: color, borderColor: color } : undefined}
      />
    );
  }
  return <span className={"pips " + (size === 'lg' ? 'lg' : '')}>{items}</span>;
}

// ── Bar ──
function Bar({ value, max = 5, thick = false, color }) {
  const pct = Math.max(0, Math.min(1, value / max)) * 100;
  return (
    <div className={"bar-track" + (thick ? ' bar-thick' : '')}>
      <div className="bar-fill" style={{ width: pct + '%', background: color || undefined }} />
    </div>
  );
}

// ── Stars (SVG, 1–5) ──
function Stars({ value, max = 5, size = 'md' }) {
  const items = [];
  for (let i = 1; i <= max; i++) {
    const filled = i <= value;
    items.push(
      <svg key={i} className="star" viewBox="0 0 24 24" fill="none">
        <path
          d="M12 2.5l2.95 6 6.6.96-4.78 4.66 1.13 6.58L12 17.6 6.1 20.7l1.13-6.58L2.45 9.46l6.6-.96L12 2.5z"
          fill={filled ? 'currentColor' : 'transparent'}
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
      </svg>
    );
  }
  return <span className={"stars " + (size === 'lg' ? 'lg' : '')}>{items}</span>;
}

// ── Radar (5 axes for skills, sized by viewBox) ──
function Radar({ values, labels, size = 220, color }) {
  // values: array of numbers (1..5)
  const keys = Object.keys(values);
  const n = keys.length;
  const cx = size / 2;
  const cy = size / 2;
  const r = size * 0.36;
  const max = 5;

  const angleFor = (i) => -Math.PI / 2 + (i * 2 * Math.PI) / n;
  const pt = (i, val) => {
    const a = angleFor(i);
    const rr = (val / max) * r;
    return [cx + Math.cos(a) * rr, cy + Math.sin(a) * rr];
  };
  const gridPoly = (level) => keys.map((_, i) => pt(i, level)).map(p => p.join(',')).join(' ');
  const valuePoly = keys.map((k, i) => pt(i, values[k] || 0)).map(p => p.join(',')).join(' ');

  return (
    <svg className="radar" viewBox={`0 0 ${size} ${size}`} width="100%" preserveAspectRatio="xMidYMid meet">
      {[1,2,3,4,5].map(lvl => (
        <polygon key={lvl}
          points={gridPoly(lvl)}
          fill="none"
          stroke={lvl === 5 ? 'currentColor' : '#D8D0FF'}
          strokeOpacity={lvl === 5 ? 0.6 : 0.5}
          strokeWidth={lvl === 5 ? 1.2 : 0.6}
        />
      ))}
      {keys.map((k, i) => {
        const [x, y] = pt(i, 5);
        return <line key={k} x1={cx} y1={cy} x2={x} y2={y} stroke="#D8D0FF" strokeWidth="0.6" />;
      })}
      <polygon
        points={valuePoly}
        fill={color || 'currentColor'}
        fillOpacity="0.22"
        stroke={color || 'currentColor'}
        strokeWidth="1.8"
        strokeLinejoin="round"
      />
      {keys.map((k, i) => {
        const [x, y] = pt(i, values[k] || 0);
        return <circle key={k+'-d'} cx={x} cy={y} r="2.6" fill={color || 'currentColor'} />;
      })}
      {labels && keys.map((k, i) => {
        const [x, y] = pt(i, 5.55);
        return (
          <text key={k+'-l'} x={x} y={y} textAnchor="middle" dominantBaseline="middle"
            fontSize={size < 180 ? 8.5 : 9.5} fontWeight="800"
            fill="#3a3360"
            style={{textTransform: 'uppercase', letterSpacing: '0.4px'}}>
            {labels[k] || k}
          </text>
        );
      })}
    </svg>
  );
}

// ── Skill chart driven by chartStyle prop ──
function SkillChart({ skills, chartStyle, layout = 'rows', size = 200 }) {
  // skills: { speaking: 3, ... }
  if (chartStyle === 'radar') {
    return (
      <div style={{color: 'var(--report-accent)', display: 'grid', placeItems: 'center'}}>
        <Radar values={skills} labels={SKILL_LABELS_PT} size={size} />
      </div>
    );
  }
  return (
    <div className="student-skills">
      {SKILL_KEYS.map(k => (
        <div className="student-skill-row" key={k}>
          <span className="student-skill-label">{SKILL_LABELS_PT[k]}</span>
          {chartStyle === 'bars' && <Bar value={skills[k]} />}
          {chartStyle === 'dots' && <span className="row"><Pips value={skills[k]} /></span>}
          {chartStyle === 'stars' && <span className="row" style={{color: 'var(--report-accent)'}}><Stars value={skills[k]} /></span>}
          <span className="student-skill-num">{skills[k]}</span>
        </div>
      ))}
    </div>
  );
}

// ── Rating row for participation/behavior sections ──
function RatingRow({ label, value, chartStyle = 'dots', compact = false }) {
  return (
    <div className={"rating-row" + (compact ? ' compact' : '')}>
      <span className="rating-label">{label}</span>
      {chartStyle === 'bars' && <div style={{width: 140}}><Bar value={value} /></div>}
      {chartStyle === 'dots' && <Pips value={value} />}
      {chartStyle === 'stars' && <span style={{color: 'var(--report-accent)'}}><Stars value={value} /></span>}
      {chartStyle === 'radar' && <Pips value={value} />}
    </div>
  );
}

// ── Scale legend ──
function ScaleLegend({ chartStyle }) {
  const labels = ['Raramente', 'Quando solicitado', 'Regularmente', 'Sempre', 'Com excelência'];
  return (
    <div className="legend">
      <span>Escala</span>
      <span className="legend-scale">
        {labels.map((l, i) => (
          <span key={i}>
            <strong style={{color: 'var(--report-accent)', fontSize: 12}}>{i + 1}</strong>
            <span style={{textTransform: 'none', letterSpacing: 0, fontWeight: 600, color: 'var(--report-text-muted)'}}>{l}</span>
          </span>
        ))}
      </span>
    </div>
  );
}

Object.assign(window, { Pips, Bar, Stars, Radar, SkillChart, RatingRow, ScaleLegend, SKILL_KEYS, SKILL_LABELS_PT });
