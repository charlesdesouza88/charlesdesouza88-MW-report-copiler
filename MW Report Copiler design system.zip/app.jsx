// Main app — view routing + tweaks panel + print orchestration.

const PALETTES = [
  { name: 'violet', colors: ['#6C3BFF', '#9B51E0', '#FF4D9D'] },
  { name: 'ink',    colors: ['#1F1147', '#6C3BFF', '#FF4D9D'] },
  { name: 'pink',   colors: ['#FF4D9D', '#6C3BFF', '#9B51E0'] },
  { name: 'forest', colors: ['#2D7D6F', '#6C3BFF', '#FF4D9D'] },
];

function App() {
  const [classes, setClasses] = React.useState(null);
  const [sourceFile, setSourceFile] = React.useState('');
  const [classIdx, setClassIdx] = React.useState(0);
  const [view, setView] = React.useState('class'); // 'class' | 'student'
  const [studentIdx, setStudentIdx] = React.useState(0);

  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "chartStyle": "bars",
    "intensity": "medium",
    "palette": "violet"
  }/*EDITMODE-END*/;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  React.useEffect(() => {
    document.body.setAttribute('data-intensity', t.intensity);
    document.body.setAttribute('data-palette', t.palette);
  }, [t.intensity, t.palette]);

  const handleLoad = (cls, name) => {
    setClasses(cls);
    setSourceFile(name);
    setClassIdx(0);
    setView('class');
  };

  const openStudent = (idx) => {
    setStudentIdx(idx);
    setView('student');
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const goClass = () => {
    setView('class');
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const reset = () => {
    setClasses(null);
    setSourceFile('');
  };

  if (!classes) {
    return <UploadView onLoad={handleLoad} />;
  }

  const cls = classes[classIdx];
  const student = cls.students[studentIdx];
  const currentPalette = PALETTES.find(p => p.name === t.palette) || PALETTES[0];

  return (
    <div>
      <div className="appbar no-print">
        <div className="appbar-logo">
          <span className="appbar-logo-mark">W</span>
          <span>Report Compiler</span>
        </div>
        <div className="appbar-class">
          <span className="appbar-class-name">{cls.class_name}</span>
          <span className="appbar-class-meta">{cls.teacher} · {cls.schedule}</span>
        </div>
        {classes.length > 1 && (
          <select
            value={classIdx}
            onChange={(e) => { setClassIdx(parseInt(e.target.value, 10)); setView('class'); }}
            style={{
              padding: '8px 10px',
              border: 'var(--report-border-width) solid var(--report-border-color)',
              borderRadius: 'var(--report-radius)',
              fontFamily: 'inherit',
              fontWeight: 800,
              fontSize: 12,
              background: 'white',
              cursor: 'pointer'
            }}
          >
            {classes.map((c, i) => (
              <option key={i} value={i}>{c.class_name}</option>
            ))}
          </select>
        )}
        <div className="appbar-spacer" />
        <div className="appbar-tabs">
          <button
            type="button"
            className={"appbar-tab " + (view === 'class' ? 'is-active' : '')}
            onClick={() => setView('class')}
          >Turma</button>
          <button
            type="button"
            className={"appbar-tab " + (view === 'student' ? 'is-active' : '')}
            onClick={() => setView('student')}
          >Aluno</button>
        </div>
        <button className="appbar-btn is-ghost" onClick={reset}>Trocar CSV</button>
        <button className="appbar-btn" onClick={() => window.print()}>Exportar PDF</button>
      </div>

      <div className="interactive-only">
        {view === 'class' && (
          <ClassView classData={cls} chartStyle={t.chartStyle} onOpenStudent={openStudent} />
        )}
        {view === 'student' && (
          <StudentView
            student={student}
            classData={cls}
            chartStyle={t.chartStyle}
            onBack={goClass}
          />
        )}
      </div>

      {/* Print pipeline — when user hits print we emit: class cover, then every student page */}
      <div className="print-only-blocks">
        <ClassView classData={cls} chartStyle={t.chartStyle} onOpenStudent={() => {}} />
        {cls.students.map((s, i) => (
          <StudentView
            key={i}
            student={s}
            classData={cls}
            chartStyle={t.chartStyle}
            embeddedForPrint
            onBack={() => {}}
          />
        ))}
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Estilo dos gráficos">
          <TweakRadio
            label="Habilidades"
            value={t.chartStyle}
            options={[
              { value: 'bars', label: 'Barras' },
              { value: 'dots', label: 'Pontos' },
              { value: 'radar', label: 'Radar' },
              { value: 'stars', label: 'Estrelas' },
            ]}
            onChange={(v) => setTweak('chartStyle', v)}
          />
        </TweakSection>

        <TweakSection label="Intensidade visual">
          <TweakRadio
            label="Borda + sombra"
            value={t.intensity}
            options={[
              { value: 'soft', label: 'Suave' },
              { value: 'medium', label: 'Média' },
              { value: 'brutal', label: 'Brutal' },
            ]}
            onChange={(v) => setTweak('intensity', v)}
          />
        </TweakSection>

        <TweakSection label="Paleta">
          <TweakColor
            label="Acento"
            value={currentPalette.colors}
            options={PALETTES.map(p => p.colors)}
            onChange={(v) => {
              const match = PALETTES.find(p => JSON.stringify(p.colors) === JSON.stringify(v));
              if (match) setTweak('palette', match.name);
            }}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
