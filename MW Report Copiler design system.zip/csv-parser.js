// Tiny CSV parser supporting quoted fields and escaped quotes.
// Plus normalization → student records.

window.parseCSV = function parseCSV(text) {
  const rows = [];
  let row = [];
  let cur = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') { cur += '"'; i++; }
        else { inQuotes = false; }
      } else {
        cur += ch;
      }
    } else {
      if (ch === '"') { inQuotes = true; }
      else if (ch === ',') { row.push(cur); cur = ''; }
      else if (ch === '\n' || ch === '\r') {
        if (ch === '\r' && text[i + 1] === '\n') i++;
        row.push(cur); cur = '';
        if (row.length > 1 || row[0] !== '') rows.push(row);
        row = [];
      } else { cur += ch; }
    }
  }
  if (cur.length || row.length) { row.push(cur); rows.push(row); }

  if (!rows.length) return [];
  const headers = rows[0].map(h => h.trim());
  return rows.slice(1).map(r => {
    const obj = {};
    headers.forEach((h, i) => { obj[h] = (r[i] ?? '').trim(); });
    return obj;
  });
};

window.normalizeStudents = function normalizeStudents(rawRows) {
  // Group by class
  const classMap = new Map();
  rawRows.forEach(r => {
    const key = r.class_name || 'Turma sem nome';
    if (!classMap.has(key)) {
      classMap.set(key, {
        class_name: key,
        schedule: r.schedule || '',
        teacher: r.teacher || '',
        students: []
      });
    }
    const num = v => {
      const n = parseFloat((v || '').toString().replace(',', '.'));
      return isNaN(n) ? 0 : n;
    };
    let absences = [];
    try { absences = r.absences_json ? JSON.parse(r.absences_json) : []; } catch { absences = []; }

    classMap.get(key).students.push({
      name: r.name || '—',
      profile: r.profile || '',
      attention_point: r.attention_point || '',
      observation: r.observation || '',
      skills: {
        speaking: num(r.speaking),
        listening: num(r.listening),
        reading: num(r.reading),
        writing: num(r.writing),
        grammar: num(r.grammar),
      },
      attendance_percent: num(r.attendance_percent),
      absences_count: num(r.absences_count),
      absences,
      participation: {
        oral_contribution: num(r.oral_contribution),
        focus_attention: num(r.focus_attention),
        teamwork: num(r.teamwork),
      },
      behavior: {
        organization: num(r.organization),
        punctuality: num(r.punctuality),
        respect: num(r.respect),
      },
      diagnostic: {
        comunicacao: num(r.comunicacao),
        expressao_escrita: num(r.expressao_escrita),
        dominio_estrutural: num(r.dominio_estrutural),
      },
      class_metrics: {
        presenca: num(r.presenca),
        desenvolvimento: num(r.desenvolvimento),
        engajamento: num(r.engajamento),
      },
      extras: r.extras || '',
      teacher_feedback: r.teacher_feedback || '',
    });
  });
  return Array.from(classMap.values());
};

window.initialsFor = function (name) {
  return (name || '')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(s => s[0])
    .join('')
    .toUpperCase();
};
