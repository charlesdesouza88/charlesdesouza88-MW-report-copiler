// Upload landing view.

function UploadView({ onLoad }) {
  const [over, setOver] = React.useState(false);
  const inputRef = React.useRef(null);

  const handleFiles = async (files) => {
    if (!files || !files[0]) return;
    const text = await files[0].text();
    const parsed = window.parseCSV(text);
    const classes = window.normalizeStudents(parsed);
    onLoad(classes, files[0].name);
  };

  const useSample = () => {
    const parsed = window.parseCSV(window.MW_SAMPLE_CSV_FULL);
    const classes = window.normalizeStudents(parsed);
    onLoad(classes, 'amostra.csv');
  };

  return (
    <div className="upload-wrap">
      <div className="upload-card">
        <div className="eyebrow" style={{marginBottom: 10}}>Mister Wiz · Relatórios</div>
        <h1 className="upload-title">Gere boletins gráficos em segundos.</h1>
        <p className="upload-sub">
          Solte um arquivo <strong>.csv</strong> com seus alunos. Cada linha vira um aluno;
          a coluna <em>class_name</em> agrupa os alunos por turma. Você verá uma prévia interativa
          e poderá exportar para PDF.
        </p>

        <div
          className={"upload-drop" + (over ? ' is-over' : '')}
          onDragOver={(e) => { e.preventDefault(); setOver(true); }}
          onDragLeave={() => setOver(false)}
          onDrop={(e) => { e.preventDefault(); setOver(false); handleFiles(e.dataTransfer.files); }}
          onClick={() => inputRef.current && inputRef.current.click()}
        >
          <span className="upload-drop-label">Arraste o CSV aqui</span>
          <span className="upload-drop-hint">ou clique para selecionar do seu computador</span>
          <input
            ref={inputRef}
            type="file"
            accept=".csv,text/csv"
            style={{display: 'none'}}
            onChange={(e) => handleFiles(e.target.files)}
          />
        </div>

        <div className="upload-or">ou</div>

        <button className="upload-sample-btn" onClick={useSample}>
          Carregar dados de exemplo (2 turmas)
        </button>

        <div className="upload-schema">
          class_name,schedule,teacher,name,profile,attention_point,speaking,listening,reading,writing,grammar,attendance_percent,...
        </div>
      </div>
    </div>
  );
}

window.UploadView = UploadView;
