// Individual student report — combines the "relatório individual" + diagnostic sub-page.

const COMM_LEVELS = [
  '', 
  'Não sustenta um diálogo',
  'Dificuldade para desenvolver ideias complexas',
  'Consegue argumentar',
  'Desenvolve raciocínio com fluidez e boa precisão estrutural',
  'Argumenta com naturalidade, sofisticação e controle'
];
const READ_LEVELS = [
  '',
  'Dificuldade de interpretação',
  'Entende apenas o sentido geral',
  'Compreende e interpreta',
  'Analisa estrutura, intenção e vocabulário',
  'Demonstra leitura crítica e interpretação aprofundada'
];
const STRUCT_LEVELS = [
  '',
  'Falhas frequentes no uso de estruturas',
  'Erros recorrentes em construções complexas',
  'Apenas desvios que não comprometem a compreensão',
  'Aplica estruturas complexas',
  'Utiliza estruturas avançadas com precisão'
];

function StudentView({ student, classData, chartStyle, onBack, embeddedForPrint = false }) {
  const Wrap = embeddedForPrint ? 'div' : 'div';
  return (
    <Wrap className={"page" + (embeddedForPrint ? ' student-page' : '')}>
      {!embeddedForPrint && (
        <button className="back-btn interactive-only" onClick={onBack}>← Voltar à turma</button>
      )}
      <div className="student-page">
        <header className="student-page-head">
          <div className="student-avatar" style={{width: 64, height: 64, fontSize: 22}}>
            {window.initialsFor(student.name)}
          </div>
          <div>
            <div className="eyebrow">Relatório individual · {classData.class_name}</div>
            <h1 className="student-page-name">{student.name}</h1>
            <div className="student-page-meta">
              <span>Turma: <strong>{classData.class_name}</strong></span>
              <span>Horário: <strong>{classData.schedule}</strong></span>
              <span>Teacher: <strong>{classData.teacher}</strong></span>
            </div>
          </div>
          <div className="attendance-pct">
            <span className="attendance-pct-num">{Math.round(student.attendance_percent)}%</span>
            <span className="attendance-pct-label">Presença</span>
          </div>
        </header>

        {/* Row 1: Frequência + Participação */}
        <div className="report-grid">
          <div className="r-card">
            <div className="eyebrow" style={{marginBottom: 4}}>Frequência</div>
            <h3 className="card-title">Aulas perdidas</h3>
            <div className="row" style={{gap: 18, marginBottom: 14}}>
              <div>
                <div className="class-stat-label" style={{color: 'var(--report-text-muted)'}}>Faltas</div>
                <div style={{fontSize: 32, fontWeight: 900, color: 'var(--report-accent)', letterSpacing: -1}}>
                  {student.absences_count}
                </div>
              </div>
              <div style={{flex: 1}}>
                <div className="class-stat-label" style={{color: 'var(--report-text-muted)'}}>Nível de presença</div>
                <div style={{marginTop: 8}}><Bar value={student.attendance_percent} max={100} thick /></div>
                <div style={{marginTop: 4, fontSize: 11, color: 'var(--report-text-muted)', fontWeight: 700}}>
                  {student.attendance_percent}% das aulas atendidas
                </div>
              </div>
            </div>
            {student.absences && student.absences.length > 0 ? (
              <div className="absence-list">
                {student.absences.map((a, i) => (
                  <div className="absence" key={i}>
                    <div className="absence-date">{a.date}</div>
                    <div>
                      <div className="absence-title">{a.title}</div>
                      <div className="absence-notes">{a.notes}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{fontSize: 12, color: 'var(--report-text-muted)', fontWeight: 600, fontStyle: 'italic'}}>
                Nenhuma falta registrada com conteúdo perdido.
              </div>
            )}
          </div>

          <div className="r-card">
            <div className="eyebrow" style={{marginBottom: 4}}>Participação</div>
            <h3 className="card-title">Em sala de aula</h3>
            <RatingRow label="Contribuição oral" value={student.participation.oral_contribution} chartStyle={chartStyle} />
            <RatingRow label="Foco e atenção" value={student.participation.focus_attention} chartStyle={chartStyle} />
            <RatingRow label="Trabalho em equipe" value={student.participation.teamwork} chartStyle={chartStyle} />
            <ScaleLegend chartStyle={chartStyle} />
          </div>
        </div>

        {/* Row 2: Desenvolvimento (skills) + Comportamento */}
        <div className="report-grid" style={{marginTop: 18}}>
          <div className="r-card">
            <div className="eyebrow" style={{marginBottom: 4}}>Desenvolvimento</div>
            <h3 className="card-title">Habilidades de idioma</h3>
            <SkillChart skills={student.skills} chartStyle={chartStyle} size={220} />
          </div>

          <div className="r-card">
            <div className="eyebrow" style={{marginBottom: 4}}>Comportamento</div>
            <h3 className="card-title">Sala de aula</h3>
            <RatingRow label="Organização" value={student.behavior.organization} chartStyle={chartStyle} />
            <RatingRow label="Pontualidade" value={student.behavior.punctuality} chartStyle={chartStyle} />
            <RatingRow label="Respeito às regras" value={student.behavior.respect} chartStyle={chartStyle} />
            <div className="legend">
              <span>Critérios</span>
              <span style={{marginLeft: 'auto', textTransform: 'none', letterSpacing: 0, fontWeight: 600, color: 'var(--report-text-muted)'}}>
                Material, horários e respeito ao ambiente.
              </span>
            </div>
          </div>
        </div>

        {/* Row 3: Diagnóstico aprofundado */}
        <div className="section-head" style={{margin: '28px 0 12px'}}>
          <div>
            <div className="eyebrow">Diagnóstico aprofundado</div>
            <h2 className="section-title">Comunicação · Leitura · Estrutura</h2>
          </div>
          <p className="section-sub">Escala 1–5. Critério ao lado do nível atingido.</p>
        </div>

        <div className="diag-tri">
          <DiagCard label="Comunicação" value={student.diagnostic.comunicacao} levels={COMM_LEVELS} chartStyle={chartStyle} />
          <DiagCard label="Expressão escrita" value={student.diagnostic.expressao_escrita} levels={READ_LEVELS} chartStyle={chartStyle} />
          <DiagCard label="Domínio estrutural" value={student.diagnostic.dominio_estrutural} levels={STRUCT_LEVELS} chartStyle={chartStyle} />
        </div>

        {/* Row 4: Feedback do professor + Recomendações */}
        <div className="report-grid" style={{marginTop: 18, gridTemplateColumns: '1.4fr 1fr'}}>
          <div className="r-card">
            <div className="eyebrow" style={{marginBottom: 4}}>Feedback do professor</div>
            <h3 className="card-title">{classData.teacher}</h3>
            <div className="feedback">
              <p>{student.teacher_feedback}</p>
            </div>
          </div>
          <div className="r-card">
            <div className="eyebrow" style={{marginBottom: 4}}>Recomendações</div>
            <h3 className="card-title">Direcionamento</h3>
            <div className="feedback" style={{fontSize: 13}}>
              <p>{student.extras || 'Sem direcionamentos específicos no momento.'}</p>
            </div>
            <div className="interventions">
              <Intervention label="Reposições" />
              <Intervention label="Reforço" />
              <Intervention label="Aula extra" />
            </div>
          </div>
        </div>
      </div>
    </Wrap>
  );
}

function DiagCard({ label, value, levels, chartStyle }) {
  return (
    <div className="diag-card">
      <div className="diag-card-label">{label}</div>
      <div className="diag-card-name" style={{visibility: 'hidden', height: 0, margin: 0}}>—</div>
      <div className="diag-card-score">
        <span className="diag-card-num">{value}</span>
        <span className="diag-card-of">/ 5</span>
      </div>
      {chartStyle === 'bars' && <Bar value={value} thick />}
      {chartStyle === 'dots' && <Pips value={value} size="lg" />}
      {chartStyle === 'stars' && <span style={{color: 'var(--report-accent)'}}><Stars value={value} size="lg" /></span>}
      {chartStyle === 'radar' && <Pips value={value} size="lg" />}
      <div className="diag-card-desc">
        <strong style={{color: 'var(--report-accent)'}}>Nível {value}:</strong>{' '}
        {levels[value] || '—'}
      </div>
    </div>
  );
}

function Intervention({ label }) {
  return (
    <div className="intervention">
      <div className="intervention-label">{label}</div>
      <div className="intervention-dates">
        <span className="intervention-date">__ / __</span>
        <span className="intervention-date">__ / __</span>
        <span className="intervention-date">__ / __</span>
      </div>
    </div>
  );
}

window.StudentView = StudentView;
