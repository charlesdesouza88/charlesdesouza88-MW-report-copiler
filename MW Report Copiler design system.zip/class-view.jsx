// Class diagnostic view — the cover page (all students at a glance + reinforcement).

const PROFILE_TAGS = {
  'Self-learned': 'ok',
  'Quick-learned': 'ok',
  'Seguro': 'ok',
  'Disponibilidade': 'ok',
  'Muito interessada': 'ok',
  'Baixo engajamento': 'alert',
  'Acerta acima de 80%': 'ok',
};

function ClassMetricBar({ label, value, max = 5 }) {
  return (
    <div className="class-stat">
      <div className="class-stat-label">{label}</div>
      <div className="class-stat-value">
        <span className="class-stat-num">{value.toFixed(1)}</span>
        <span className="class-stat-of">/ {max}</span>
      </div>
      <div className="class-stat-bar"><Bar value={value} max={max} thick /></div>
    </div>
  );
}

function StudentCard({ student, chartStyle, onOpen, idx }) {
  const obsTag = PROFILE_TAGS[student.observation] || '';
  return (
    <button className="student-card" onClick={onOpen} type="button">
      <div className="student-card-top">
        <div className="student-avatar">{window.initialsFor(student.name)}</div>
        <div>
          <div className="student-name">{student.name}</div>
          <div className="student-sub">Aluno · {String(idx + 1).padStart(2, '0')}</div>
        </div>
      </div>
      <div className="student-tags">
        {student.profile && <span className="tag">{student.profile}</span>}
        {student.attention_point && <span className="tag alert">{student.attention_point}</span>}
        {student.observation && <span className={"tag " + obsTag}>{student.observation}</span>}
      </div>
      <SkillChart skills={student.skills} chartStyle={chartStyle} size={180} />
    </button>
  );
}

function ClassView({ classData, chartStyle, onOpenStudent }) {
  const students = classData.students;
  const N = students.length || 1;
  const avg = (key) => students.reduce((s, st) => s + (st.class_metrics[key] || 0), 0) / N;
  const presenca = avg('presenca');
  const desenvolvimento = avg('desenvolvimento');
  const engajamento = avg('engajamento');

  return (
    <div className="page">
      <div className="class-head">
        <div>
          <div className="eyebrow">Diagnóstico de Turma · 2026</div>
          <h1 className="class-head-title">{classData.class_name}</h1>
          <div className="class-head-meta">
            <span><strong>{classData.schedule}</strong></span>
            <span>Teacher: <strong>{classData.teacher}</strong></span>
            <span><strong>{students.length}</strong> alunos</span>
          </div>
        </div>
        <div className="class-stats">
          <ClassMetricBar label="Presença" value={presenca} />
          <ClassMetricBar label="Desenvolvimento" value={desenvolvimento} />
          <ClassMetricBar label="Engajamento" value={engajamento} />
        </div>
      </div>

      <div className="section-head">
        <div>
          <div className="eyebrow">Índices de desenvolvimento</div>
          <h2 className="section-title">Perfil e habilidades por aluno</h2>
        </div>
        <p className="section-sub">
          Cada card mostra perfil natural, ponto de atenção, observação e as cinco habilidades-chave (1–5).
          Clique em um aluno para abrir o relatório individual.
        </p>
      </div>

      <div className="student-grid">
        {students.map((s, i) => (
          <StudentCard key={s.name + i} student={s} idx={i} chartStyle={chartStyle} onOpen={() => onOpenStudent(i)} />
        ))}
      </div>

      <div className="section-head">
        <div>
          <div className="eyebrow">Direcionamento de reforço</div>
          <h2 className="section-title">Membros e intervenções</h2>
        </div>
        <p className="section-sub">
          Plano de reforço, material extra e aulas adicionais por aluno conforme observado em sala.
        </p>
      </div>

      <div className="directives">
        {students.filter(s => s.extras).map((s, i) => (
          <div className="directive" key={s.name + i}>
            <div>
              <div className="directive-name">{s.name.split(' ')[0]}</div>
              <div className="directive-sub">{s.profile} · {s.attention_point}</div>
            </div>
            <div className="directive-body">{s.extras}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

window.ClassView = ClassView;
